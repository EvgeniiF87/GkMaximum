## [1.0.2](https://github.com/yeutech-lab/expo-custom-switch/compare/v1.0.1...v1.0.2) (2020-02-20)


### Bug Fixes

* **lighten:** less lighten on the left ([31c95d0](https://github.com/yeutech-lab/expo-custom-switch/commit/31c95d081f86db6168bb8d2c5e5bf7f5387a55fc))

## [1.0.1](https://github.com/yeutech-lab/expo-custom-switch/compare/v1.0.0...v1.0.1) (2020-02-20)


### Bug Fixes

* **CustomSwitch:** allow parameters to customize the icon ([db51cd1](https://github.com/yeutech-lab/expo-custom-switch/commit/db51cd1494bc1ef1a3bdff65b01c4eb975e65890))

# 1.0.0 (2020-02-20)


### Bug Fixes

* **CustomSwitch:** added CustomSwitch ([8e21e40](https://github.com/yeutech-lab/expo-custom-switch/commit/8e21e40c179abcfe5f2f1afedf6bf99c450ddb89))
* **types:** fix types ([9def3ec](https://github.com/yeutech-lab/expo-custom-switch/commit/9def3ec1ad4fe1c3677697e3db03e90754bede94))
